# 🎵 RHYTHM — Fluxo de Trabalho do Ensina.app

## 🎯 Objetivo
Garantir um **ritmo de desenvolvimento consistente e colaborativo**,  
mantendo a coerência entre o backend (IA) e o frontend (plataforma).

## 🧩 Estrutura de Trabalho
1. **Planejamento**  
   - Revisão do Vision.md  
   - Definição de metas semanais  

2. **Desenvolvimento Modular**  
   - Cada agente (Zeus, Gaia, Pulga, Xavier, Repi) possui um módulo independente.  
   - Rotas, prompts e lógica separados para fácil manutenção.  

3. **Testes e Feedback**
   - Testes locais com Uvicorn  
   - Logs estruturados e revisões automáticas pela Pulga  

4. **Deploy e Integração**
   - CI/CD configurável via Vercel e AWS  
   - Deploy automático após push na branch `main`

---

## 🧠 Comunicação entre Agentes
| Origem | Destino | Ação |
|--------|----------|------|
| Gaia | Zeus | Solicita execução de código |
| Pulga | Gaia | Revisa textos e respostas |
| Xavier | Todos | Supervisiona o processo de ensino |
| Repi | Usuário | Interage via chat e WhatsApp |

---

## 🪜 Metodologia
- Desenvolvimento iterativo em **sprints curtas**
- Cada sprint adiciona um módulo ou função de agente
- Revisões semanais documentadas em `/docs`

---

## ⚙️ Ferramentas
- GitHub (controle de versão)
- Cursor IDE (IA colaborativa)
- OpenAI GPT-5 (LLM)
- Vercel/AWS (deploy)

---

🧭 **Meta final:** criar um ciclo autônomo de ensino, onde IA e humanos aprendem e evoluem juntos.





🧠 Resumo Técnico – Projeto Ensina.app (Fase 1)
🎯 Visão Geral

Ensina.app é uma plataforma de aprendizado inteligente e colaborativa que utiliza múltiplos agentes de IA (Zeus, Gaia, Pulga e Xavier) para criar, orientar e avaliar cursos interativos e personalizados.
O objetivo central é gamificar o processo de ensino, permitindo que os alunos aprendam com mentores digitais especializados e acompanhem sua evolução de forma didática e envolvente.

⚙️ Arquitetura e Infraestrutura

Backend: FastAPI com rotas individuais para cada agente.

Servidor local: Uvicorn (modo reload habilitado para desenvolvimento).

Gerenciamento de dependências: requirements.txt

Ambiente isolado: venv (Python 3.12+)

Configurações sensíveis: .env com chaves da OpenAI (para testes com LLMs).

Estrutura de diretórios:

ensina.app/
├── backend/
│   ├── main.py
│   ├── routers/
│   │   ├── zeus_router.py
│   │   ├── gaia_router.py
│   │   ├── pulga_router.py
│   │   └── xavier_router.py
│   ├── prompts/
│   │   ├── zeus_prompt.py
│   │   ├── gaia_prompt.py
│   │   ├── pulga_prompt.py
│   │   └── xavier_prompt.py
│   └── utils/ (reservado para ferramentas auxiliares)
├── docs/
├── RHYTHM.md
├── vision.md
└── README.md

🤖 Agentes Atuais
🧩 Zeus – Mentor

Papel: orienta o aluno no processo de aprendizado, fornece dicas e direcionamentos.

Estilo: direto, confiante e didático.

Testado com endpoint: /zeus

⚙️ Gaia – Executor

Papel: executa códigos e implementa instruções técnicas.

Estilo: prática, proativa e objetiva.

Testado com endpoint: /gaia

🧠 Pulga – Avaliadora

Papel: revisa códigos e conteúdos, detectando erros e sugerindo melhorias.

Estilo: sarcástica, inteligente e precisa.

Testado com endpoint: /pulga

👨‍🏫 Professor Xavier – Diretor

Papel: supervisiona os demais agentes e orienta o usuário no uso da plataforma.

Estilo: sábio, calmo, levemente formal e empático.

Endpoint: /xavier

💾 Integrações e Conexões

GitHub: Repositório ativo e vinculado
🔗 https://github.com/Christianx3m/ensina.app

Controle de versão: Git (branch principal: main)

Planejamento de roadmap: migrando para Notion, com visualizações em Kanban, Timeline e Tabela.

🧩 Status Atual
Área	Situação	Observações
Estrutura de backend	✅ Completa	FastAPI funcional
Rotas dos agentes	✅ Testadas	Todas respondendo
Prompts e personalidades	⚙️ Ajustando	Xavier atualizado, demais revisados
Documentação (README, RHYTHM, VISION)	⚙️ Em atualização	Conteúdo conceitual e técnico sendo revisado
Integração GitHub	✅ Ativa	Repo público
Infraestrutura (deploy)	🚧 Pendente	Planejar AWS e Vercel
Sistema de usuários	🚧 Próxima etapa	Cadastro, convites e perfis
Agente Repi (secretária)	🚧 Planejamento	Interação via WhatsApp/API
🗺️ Próximos Passos

🧱 Criar módulo de usuários e convites

CRUD de usuários

Sistema de convites com validação por token

Perfis (Aluno, Professor, Admin)

🧩 Planejar estrutura de dados e banco (PostgreSQL ou DynamoDB)

🌐 Preparar deploy inicial

Backend → Vercel ou AWS Lambda

Variáveis de ambiente seguras (.env)

💬 Implementar Repi (assistente de comunicação)

Chat e suporte via WhatsApp API

Integração com base de cursos e perfis

🧾 Expandir documentação (Vision + Rhythm + README detalhado)

🧭 Objetivo da Fase 2

Criar a fundação do sistema de usuários e autenticação, integrar persistência de dados e iniciar o desenho da camada de aprendizado interativo, com gamificação e progressão de cursos.


---

## 🧩 Nova Seção — Inclusão e Acessibilidade

---

## 🏆 Progressão e Ações do Usuário

O Ensina.app reconhece ações e marcos importantes do aluno, recompensando seu progresso.

### 🎯 Ações que geram evolução
- Criar ou concluir projetos.
- Participar de grupos colaborativos.
- Ajudar outros alunos (revisões).
- Publicar cursos e compartilhar aprendizados.
- Usar a plataforma com constância e equilíbrio.

Cada ação gera **níveis, títulos e créditos**, que podem ser usados no **Shop** para comprar cosméticos ou efeitos para o avatar.

A **REPI** registra todas as conquistas e gera automaticamente certificados, marcos e estatísticas do aluno.

---

## 🧩 Modo Colaborativo

Os alunos podem formar **grupos de estudo e desenvolvimento de projetos**.  
Cada grupo tem uma **sala interativa**, onde é possível:
- Conversar por voz ou chat;
- Dividir tarefas;
- Revisar trabalhos de outros;
- Receber ajuda dos agentes (Xavier, Zeus, Gaia e Pulga).

A REPI registra e organiza os documentos e entregas do grupo.

---

## 🔊 Inclusão e Aprendizado por Voz

O Ensina.app também funciona de forma **acessível e multimodal**:
- O aluno pode aprender por **voz, imagem ou toque**.
- Pode enviar **fotos de escritas manuais**, e os agentes corrigem ou interpretam.
- O aprendizado é gamificado para ser lúdico e acessível mesmo para quem nunca leu.

---

## 🎮 Loop Gamificado de Aprendizado


Cada volta nesse ciclo gera **créditos, XP e conquistas visuais** no mundo virtual do Ensina.app.
