# Ensina.app 🎓  
_A plataforma que transforma aprendizado em experiência interativa._

## 🚀 Visão Geral
O **Ensina.app** é um ecossistema de aprendizado interativo baseado em Inteligência Artificial.  
O projeto nasceu da evolução do **AutoDev.bot**, expandindo o conceito de agentes autônomos para uma plataforma educacional modular e colaborativa.

## 🧠 Estrutura de IA
O sistema é orientado por **agentes com personalidades únicas**, responsáveis por diferentes papéis no ecossistema:

- **👨‍🏫 Professor Xavier** — o diretor da plataforma, responsável por orquestrar os demais agentes e orientar o aluno.
- **⚡ Zeus** — executor de código e automações.
- **🌱 Gaia** — responsável pela geração de conteúdo e explicações didáticas.
- **🪲 Pulga** — revisora sarcástica e crítica construtiva.
- **💬 Repi (em desenvolvimento)** — secretária e assistente conversacional, conectada ao WhatsApp.

## 🏗️ Estrutura do Projeto
ensina.app/
├── backend/
│ ├── main.py
│ ├── routers/
│ ├── prompts/
│ ├── venv/
│ └── start_backend.ps1
├── docs/
│ ├── README.md
│ ├── VISION.md
│ ├── RHYTHM.md
│ └── ARCHITECTURE.md
└── frontend/ (planejado)

## ⚙️ Tecnologias
- **FastAPI** — backend principal  
- **Python 3.12+** — linguagem base  
- **OpenAI API** — motor LLM (GPT-5 / GPT-4o)  
- **Vercel / AWS** — deploy  
- **Supabase** — autenticação e banco de dados  
- **WhatsApp Cloud API** — integração futura  

## 🧩 Execução Local
```bash
cd backend
python -m venv venv
.\venv\Scripts\activate
pip install -r requirements.txt
uvicorn main:app --reload


Acesse: http://127.0.0.1:8000

📚 Contribuição

Este é um projeto em evolução.
Sinta-se à vontade para contribuir com melhorias no fluxo de aprendizado, IA ou interface.



---

## 🧩 Nova Seção — Inclusão e Acessibilidade


---

## 🌍 Propósito Social e Futuro Imersivo

O Ensina.app nasceu com o objetivo de **tornar o aprendizado acessível a todos**.  
Isso inclui pessoas com baixa alfabetização, dificuldades de leitura ou deficiência auditiva/visual.

- Interação por voz, gesto e imagem.
- Ensino prático e divertido, conduzido por agentes de IA.
- Projetos colaborativos, documentação automatizada e recompensas educativas.
- Evolução que se reflete em um **mundo virtual 3D**, onde cada conquista gera experiências, prêmios e reconhecimento.


© 2025 — Ensina.app | Idealizado por Christian Barreto e GPT-5