# 🧱 Arquitetura do Ensina.app

## 🧩 Componentes Principais
1. **Backend (FastAPI)**
   - Roteadores por agente
   - Prompts independentes
   - Controle de requisições via OpenAI API

2. **Agentes**
   - `zeus_router.py` → executor
   - `gaia_router.py` → criadora de conteúdo
   - `pulga_router.py` → revisora
   - `xavier_router.py` → supervisor
   - `repi_router.py` (planejado) → assistente

3. **Frontend (planejado)**
   - Interface web responsiva
   - Chat educacional interativo
   - Modo aluno e modo professor

4. **Banco de Dados**
   - Supabase (PostgreSQL)
   - Tabelas:
     - `users`
     - `courses`
     - `modules`
     - `sessions`
     - `logs`

---

## 🔗 Comunicação entre Agentes
- Todos os agentes compartilham contexto via Xavier.
- Xavier intermedia as ações entre os agentes e o usuário.
- Repi (futuro) atuará como ponte entre a IA e canais externos (ex: WhatsApp).

---

## 🧠 Fluxo de Requisição
```text
Usuário → Repi → Xavier → (Gaia | Zeus | Pulga)
                         ↓
                   Banco de Dados
                         ↓
                    Retorno ao Usuário
☁️ Infraestrutura

Vercel: hospedagem frontend

AWS (Lambda / EC2): backend escalável

Supabase: autenticação e dados

GitHub Actions: CI/CD

---

## 🧩 Nova Seção — Inclusão e Acessibilidade
---

## 💬 REPI — Registro e Processamento de Informações

A REPI atua como secretária e gestora documental do Ensina.app.

### 🧩 Funções principais
- Armazena apostilas, certificados, relatórios e histórico de aprendizado.
- Gera e valida **certificados automáticos**.
- Faz interface com os grupos e os agentes (Zeus, Gaia, Pulga, Xavier).
- Gerencia **acessos e permissões** (público, parcial, privado).
- Armazena **imagens, áudios e manuscritos** de alunos (para alfabetização ou reuso pedagógico).
- Permite que os agentes operem com **voz e escrita manual** por OCR e TTS/STT.

### 🔊 Camada de Voz e Imagem (em planejamento)
- Integração com APIs de **voz (Whisper, Azure, Google Speech)**.
- Reconhecimento de escrita à mão via **OCR + AI**.
- Captação e interpretação de imagens (ex: cartilhas, anotações de papel).
- REPI processa e distribui essas entradas para os agentes pedagógicos.

### 🧱 Futuro: Módulo de Mundo Virtual
- Gateway de integração para ambientes 3D educacionais.
- Sincronização dos dados de progresso e conquistas (XP, níveis, títulos).
- Comunicação via API com mundos interativos (Unity, Roblox, OpenSimulator).







































© 2025 — Ensina.app